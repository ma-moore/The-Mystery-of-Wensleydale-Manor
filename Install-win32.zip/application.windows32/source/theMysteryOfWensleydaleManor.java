import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class theMysteryOfWensleydaleManor extends PApplet {

/* The Mystery of WensleyDale Manor
This is an exploration/puzzle game set in a haunted house.
You wake up and must find your way around the house, solving puzzles you find along the way and finding the house' secrets.
A walkthrough is provided within the game folders ("walkthrough.txt")
Have fun!

Credits: Characters do not belong to me, though all artwork is mine
*/

int gridSize; //Universal size marker, applicable for grid as well as character size etc - I have amped this slightly for drawing of people as they come out a bit small
boolean missionStart; //Chosen as global for simplicity - indicates whether the primary mission of the game has begun
boolean gameOver; //End of game - when the primary mission is complete (player may still explore)

Player player; //Player class - user operated character
OutputText textDisplay;  //The information display for the player interactions
InventoryText inventoryDisplay; //Lists the inventory on screen for easy reference
ArrayList<NPC> characters; //Array List of NPCs - allows simple adding of more characters when needed (and control of all through one for loop)
ArrayList<Item> items; //Array list of items - allows removal of item from location when collected
Level[] levels; //The map, 5 floors of the house and grounds
Lever[] levers; //Small array (2) of levers for special puzzles - would be expanded if the game was larger


public void setup()
{  
  size(6000,6000); //Starts enormous as the colour input system only works if the the code can see the full image
  gridSize = 50; //Everything is arranged on a 50x50 grid
  missionStart = false; 
  
  mapSetup(); //Most variables are set up in sub classes for visual ease when looking at the code (in the Setup tab)
  leverSetup();
  itemSetup();
  setupCharacters();
  
  player = new Player(); //No input variables as there is only one instance of player character
  textDisplay = new OutputText();
  inventoryDisplay = new InventoryText();
  
  rectMode(CORNER);
  fill(0);
  size (1000,900); //Actual screen size
}

public void draw()
{
  background(0);
  fill(0);
  levels[player.levelLoc].draw(); //Draws the current level
  
  player.draw();
  player.climb(); //Checks if the player is on any of the stairs and then sends them up or down if they are
  
  for (int i=0;i<characters.size();i++) //Single loop controls all instances of the character class (including some which aren't quite characters
  {
    characters.get(i).move();
    characters.get(i).draw();
  }
  for (int i=0;i<items.size();i++) //Draws all versions of the items class
  {
    items.get(i).draw();
  }
  for (int i=0;i<levers.length;i++)
  {
    levers[i].draw(); //Drawn on top because they hide things.
  }
  
  inventoryDisplay.draw(); //Information displays drawn on top so they aren't covered by the map etc
  inventoryDisplay.printToScreen();
  textDisplay.updateOutput();
  textDisplay.draw();
  textDisplay.printToScreen();  
}

class Blink extends NPC //Very basic NPC class - moves freely around the grounds and can be interacted with, but not essential to the game
{
  Blink(int x) //Explanation of the following variables is provided in the NPC class setup (As they all use the same)
  {
    gridLoc = x;
    roomLoc = 1;
    levelLoc = 1;
    direction = 2;
    yMove = levels[levelLoc].gridWidth; //Moves up or down by the gridwidth (array of Grids is 40, 60 or 80 wide)
    xMove = 1;
    name = "Angel";
    img = loadImage(name+".gif"); 
    speech = loadStrings(name+".txt");
    counter=0;
    counterLimit=10; //Changes direction after 10 moves (or when it hits a wall)
    calmed = true;//Starts as true as they don't need 'calming' and Freddy needs to register them as calmed
  }
  
  public void speak() //Replaces the NPC version - simply provides a random line of dialogue to the player from the speech array
  {
    int r = PApplet.parseInt(random(speech.length));
    textDisplay.output.add(name+": ");
    textDisplay.output.add(speech[r]);
    textDisplay.output.add(" ");
  }
}

class CreepyGirl extends NPC //Basic version of the NPC class, doesn't move and doesn't give any items but can be interacted with
{
  
  CreepyGirl(int x, int y, int z, String n) //Meaning of these variables is covered in the NPC class
  {
    gridLoc = x; 
    roomLoc = y; 
    levelLoc = z;
    
    name = n;
    img = loadImage(name+".gif");
    speech = loadStrings(name+".txt");
    calmed = true; //Starts as true as they don't need 'calming' and Freddy needs to register them as calmed
    
    counter=0; //Used to loop dialogue
    counterLimit=speech.length-1;
  }
  
  public void move()
  {}
  
  public void speak() //Cycles through the speech lines (pairs of dialogue) and then reverts to the beginning when they have finished speaking
  {
    textDisplay.output.add(name+": ");
    textDisplay.output.add(speech[counter]);
    textDisplay.output.add(speech[counter+1]);
    counter+=2;
    if (counter>=counterLimit)
    {
      counter=0;
    }
    textDisplay.output.add(" ");
  }
}


class Door //The paths between rooms, there is an array of these for each level and they are setup in the Level class
{
  boolean locked; //If they're locked you can't pass (the gridLoc is set to blocked) but they can be unlocked with a key
  int gridLoc;
  int levelLoc;
  String token; //key name - generic word used for consistency across the program
  
  Door (int g, boolean l,int ln) 
  {
    gridLoc = g; 
    locked = l;
    levelLoc=ln;
    token="None"; //Starts as none as there was no way to set key type from a colour image - these are adjusted later in the Setup tab
  }
  
  public void unlock() //activated by the interact function of the player class
  {
    if (locked) //Only necessary to unlock if they 
    {
      boolean found=false;
      for (int i=0;i<player.inventory.size()&&!found;i++) //Scans the player's inventory to see if they have a key with the same name as the one listed - exits the loop if they do
      {
        if (player.inventory.get(i).equals(token))
        {
          found = true;
        }
      }
      if (found)
      {
        locked = false; //Unlocks the door
        levels[levelLoc].grids[gridLoc].blocked=false; //Unblocks the grid location
        textDisplay.output.add("You used the "+token+" to unlock the door"); //Lets the player know what they have done
        textDisplay.output.add(" ");
      }
      else
      {
        textDisplay.output.add("This door is locked"); //Lets the player know they haven't successfully opened the door
        textDisplay.output.add(" ");
      }
    }
  }
}



class Freddy extends NPC //Only instance of this class - Freddy is the boss and has more dialogue than anyone else. He is here to tell you what to do.
{
  Freddy() //Setup in the Setup tab - No input variables to make sure they aren't accidentally changed 
  {
    gridLoc = 1709; 
    roomLoc = 10;
    levelLoc = 2;
    name = "Freddy Krueger";
    
    calmed=true; //Already calm
    img = loadImage(name+".gif");
    speech = loadStrings(name+".txt");
    
    counter = 0;
  }
  
  public void move() //Freddy doesn't move around, just stays behind his desk. 
  {}
  
  public void speak() //A bit awkward with the setup of booleans but it works
  {
    
    
    
    textDisplay.output.add(name+": ");
    
    if (counter==0) //First time you speak to Freddy he gives you the main mission (to calm all the monsters)
    {
      missionStart = true; //Means all the monsters will talk to you instead of just sending you to speak with Freddy
      for (int i=0;i<=10;i++)
      {
        textDisplay.output.add(speech[i]); //Loops through his first 10 lines of dialogue (the introduction to the mission)
      }
      counter=1;
    }
    else if (counter==1)//Dialogue telling you you aren't done yet
    {
      textDisplay.output.add(speech[11]);
      textDisplay.output.add(speech[12]);
      textDisplay.output.add(speech[13]);
      textDisplay.output.add(speech[14]);
      
      boolean complete = true; //Easier to start as complete and change if not than the other way around
      for (int i=0; i<characters.size();i++) // Loops through all the characters and checks if they are all calm
      {
        if (characters.get(i).calmed==false)
        {
          complete=false;
          textDisplay.output.add("You still have to calm "+characters.get(i).name);
        }
      }
      if (complete) { counter=2;} //Moves to final line of dialogue if all the monsters have been calmed
      
    }
    else if (counter==2)
    {
      for (int i=15;i<speech.length;i++) //Freddy's dialogue telling you game over
      {
        textDisplay.output.add(speech[i]);
      }
      textDisplay.output.add(" "); //Output text for when the game ends. To let the player know their work is done (preferable to an end screen as the player may still want to explore
      textDisplay.output.add("From the Programmer: ");
      textDisplay.output.add("The Game is Over."); 
      textDisplay.output.add("Congratulations on your victory.");
      textDisplay.output.add("Credits: Programmer - William Moore.");
      textDisplay.output.add("End of Credits");
    }  
    textDisplay.output.add(" ");
  }
}

class Ghost extends NPC //Game relevant character - provides keys (with a few exceptions
{
  
  Ghost(int x, int y, int z, String n, String t) //Setup in the Setup tab, variable details in NPC class
  {
    gridLoc = x; 
    roomLoc = y; 
    levelLoc = z;
    
    name = n;
    token = t; //Key/item they give, generic name chosen so the variable can double as what is accepted by the monsters
    img = loadImage(name+".gif");
    calmed = true;
    speech = loadStrings(name+".txt"); 
    
    counter=2; //First two lines of dialogue just sends the player to Freddy, counter not needed for them
  }
  
  public void move() //Ghosts don't move
  {}
  
  public void speak()
  {
    textDisplay.output.add(name+": ");
    if (!missionStart) //One of two lines of text that direct the player to Freddy to start the game mission, picked randomly
    {
      if (millis()%2==1) {textDisplay.output.add(speech[0]);} 
      else {textDisplay.output.add(speech[1]);}
    }
    else if (counter<speech.length-3) //Dialogue couplets, can be any number of these but final three lines are used for other things
    {
      textDisplay.output.add(speech[counter]);
      textDisplay.output.add(speech[counter+1]);
      counter+=2;
    }
    else if (counter<speech.length-1) //When the gets to the final three lines of dialogue they hand over the key
    {
      textDisplay.output.add(speech[speech.length-3]); 
      textDisplay.output.add(speech[speech.length-2]);
      textDisplay.output.add(" ");
      counter+=2;
      player.inventory.add(token); //Key added to the inventory - only a string no object is needed
      textDisplay.output.add("You received the "+token+" from "+name+".");
    }
    else
    {
      textDisplay.output.add(speech[speech.length-1]); //Final line of dialogue indicating they are done talking 
    }
    textDisplay.output.add(" ");
  }
}

class Grave extends NPC //Listed as a character class because you read them (in a way similar to dialogue) but are just graves
{//Setup in Setup tab, details about variables listed in the NPC tab 
  Grave(int x) //Only grid location needed as Graves are only found in the outdoor section (level 1 room 1)
  {
    gridLoc = x;
    roomLoc = 1;
    levelLoc = 1;
    name = "Grave"; 
    
    img = loadImage(name+".gif");
    speech = loadStrings(name+".txt");
    calmed = true;
  }
  
  public void move()
  {}

  
  public void speak() //Speak function is a bit muddled with the three unique graves. With more time and a larger game I would have had more unique graves and set up seperate class for them.
  {
    textDisplay.output.add(name+": ");
    int temp = PApplet.parseInt(random(2,speech.length)); //Most speech is completely random from the list
    if (gridLoc == 7523||gridLoc==7525) //If the grave is in either of these coordinates the player receives the tomb Key from it
    {
      textDisplay.output.add(speech[1]); //second line of dialogue is a unique grave - a reference to the movie 'The Others'
      boolean found=false;
      for (int i=0;i<player.inventory.size();i++)
      {
        if (player.inventory.get(i).equals("Tomb Key")) //Checks to make sure they haven't already got it (otherwise you would fill your inventory with thousands of duplicates
        {
          found = true;
        }
      }
      if (!found)
      {
        player.inventory.add("Tomb Key");
      }
    }
    else if (gridLoc == 472)
    {
      textDisplay.output.add(speech[0]); //First line of dialogue is a unique grave (Freddys)
      boolean found=false;
      for (int i=0;i<player.inventory.size();i++)
      {
        if (player.inventory.get(i).equals("Freddy's Remains")) //Exists for a shortcut puzzle that lets you kill Freddy - not implemented in this version of the game due to time constraints
        {
          found = true;
        }
      }
      if (!found)
      {
        player.inventory.add("Freddy's Remains");
      }
    }
    else
    {
      textDisplay.output.add(speech[temp]);
    }
    textDisplay.output.add(" ");
    
  }
}


class Grid
{
  int room; //by default set to 0 - the outer level
  boolean blocked; //default set to blocked (easier to set it all up as null space and then change it to rooms and locations afterward) 
  float posX;
  float posY;
  
  Grid (float x, float y, boolean b)
  {
    posX = x;
    posY = y;
    room = 0; //Starts at 0, set later using a different colour map to the one used to setup the grids
    blocked = b;
  }
  
  public boolean inGrid(float x, float y) //Confirms whether or not something is in the grid square
  {
    boolean temp = false;
    if ((x>=posX)&&(x<posX+gridSize)&&(y>=posY)&&(y<posY+gridSize))
    {
      temp = true;
    }
    return temp;
  }
  
}

class Item
{
  int gridLoc, roomLoc, levelLoc;
  String name;
  PImage img;
  
  Item (int x, int y, int z, String n) //Variables setup in the Setup tab
  {
    gridLoc = x;
    roomLoc = y; //Used to tell whether or not to draw it
    levelLoc = z;
    name = n;
    img = loadImage(name+".gif"); 
  }
  
  public void draw()
  {
    if (player.levelLoc==levelLoc&&player.roomLoc==roomLoc) //Only draws if on the same level as the player and in the same room
    {
      image(img, levels[levelLoc].grids[gridLoc].posX, levels[levelLoc].grids[gridLoc].posY,gridSize*1.2f,gridSize*1.2f); //drawn slightly larger than the grid due to a misestimate of size made by me. 
    }
  }
  
  public void pickUp()
  {
    player.inventory.add(name); //Adds the name to the players' inventory. Once there the class is no longer needed, just the name string. 
    textDisplay.output.add("You have picked up "+name+".");
    textDisplay.output.add(" ");
  }
  
}




class Level
{
  int gridNo; //The number of grids on the level aka the lenght of this level's grid arrays
  int gridWidth; //Number of Grids along
  int gridHeight; //Number of of Grids down - not used outside of setup
  
  int levelLoc; //the level number
  
  int numberRooms; //the number of rooms on the level
  int numberDoors; //Number of doors on the level
  int numberStairs; //Number of stairs on the level
  
  int displacementX, displacementY; //Displacement is used to align all the levels so that movement between them is smooth.
  
  Room[] rooms; //An array of rooms, length based of numberRoooms
  Grid[] grids; //An array of grid locations (central to the phsyics engine)
  PImage back; //the background image of the level, Given more time this would be an array of images so there could be animated backgrounds
  Door[] doors; //Array of doors on the level - used to block different grid locations if they are locked
  Stair[] stairs;
  
  Level (int gn, int gw, int gh, int ln, int nr, int nd, int ns, int dx, int dy) //Setup in setup tab
  {
    gridNo = gn;
    gridWidth = gw;
    gridHeight = gh;
    levelLoc = ln;
    numberRooms = nr;
    numberDoors = nd;
    numberStairs = ns;
    displacementX = dx*gridSize;
    displacementY = dy*gridSize;
    back = loadImage("Level0"+levelLoc+".gif");
    grids = new Grid[gridNo];
    rooms = new Room[numberRooms];
    doors = new Door[numberDoors];
    stairs = new Stair[numberStairs];
    
    setupGrid(); //Setup with seperate functions to simplify the process
    setupRooms(); 
  }
  
  public void draw()
  {
    image(back,grids[0].posX,grids[0].posY); //Draws the image at location
    for (int i=0;i<rooms.length;i++) //Fills all grid locations in black if the player is not in that room
    {
      rooms[i].draw();
    }
  }
  
  public int whereAmI(float x, float y) //Returns the grid location of the x and y coordinates used to call the function
  {
    for (int i=0;i<grids.length;i++) //Checks which location on the grid the player is and returns it 
    {
      if (grids[i].inGrid(x,y))
      {
        return i;
      }
    }
    return 0;
  }

  public void setupRooms()
  {
    PImage roomColourMap = loadImage("Level0"+levelLoc+"Rooms.gif"); //Loads an image with each room highlighted a different color
    image(roomColourMap,displacementX,displacementY);
    int[] room = new int[15];
    room[0] = color(255,0,0); //Easiest way was declaring each colour individually (no accurate way of doing it with a for loop unforunately
    room[1] = color(0,255,0);
    room[2] = color(0,0,255);
    room[3] = color(255,0,255);
    room[4] = color(0,255,255);
    room[5] = color(255,255,0);
    room[6] = color(125,0,0);
    room[7] = color(0,125,0);
    room[8] = color(0,0,125);
    room[9] = color(125,0,125);
    room[10] = color(0,125,125);
    room[11] = color(125,125,0);
    room[12] = color(200,0,0);
    room[13] = color(0,200,0);
    room[14] = color(0,0,200);
    
    for (int i=0;i<grids.length;i++)
    {
      int c = get(PApplet.parseInt(grids[i].posX+1),PApplet.parseInt(grids[i].posY+1)); //Gets the color value at the grid coordinate (+1 to be on the safe side)
      boolean set=false;
      for (int j=0;j<room.length&&!set;j++) //Loops to see what room colour that coordinate has
      {
        if (c==room[j]) 
        {
          grids[i].room = j; //Sets the room number
          set = true;//bounces out of the grid when done
        }
      }
    }
  }
  
  public void setupGrid()
  {
    PImage colourMap = loadImage("Level0"+levelLoc+"Colours.gif"); //Loads a color map to indicate which squares on the grid are blocked, stairs, etc etc. Inspiration for this provided during my presentation on my progress in this game.
    image(colourMap, 0,0);
    
    int currentDoor = 0; //Keeps track of which Door on the level the loop is setting up
    int currentStair = 0; //Keeps track of which Stair on the level the loop is setting up
    
    int blocked = color(255,0,0);//Red and blue for the spaces you can walk around or no
    int unblocked = color(0,0,255);
    int lockedDoors = color(0,255,0); //Doors are locked or not locked 
    int unlockedDoors = color(0,125,0);
    
    int stairsUpUp = color(255,0,255); //Stair types needed: UP-LRUD, DOWN-LRUD = 8xColours - Two bases Pink and Yellow w/colour variations
    int stairsUpDown = color(200,0,200); //Chose individual names instead of an array as at no stage would I be able to simply loop through them (specifications too unique per direction)
    int stairsUpLeft = color(150,0,150);
    int stairsUpRight = color(100,0,100);
    
    int stairsDownUp = color(0,255,255);
    int stairsDownDown = color(0,200,200);
    int stairsDownLeft = color(0,150,150);
    int stairsDownRight = color(0,100,100);
    
    for (int i=0;i<gridHeight;i++) //i and j loop through the grid based on height and width
    {
      for (int j=0;j<gridWidth;j++)
      {
        int c = get(j*gridSize+1, i*gridSize+1); //Checks the colour at the current grid
        
        if (c==blocked) //Blocked space - creates a grid that you can't walk through
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, true);
        }
        else if (c==unblocked)//unblocked space - creates a grid you can walk through
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, false);
        }
        else if (c==lockedDoors)//locked doors - sets up the locked door (key set elsewhere)
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, true); //Sets grid to blocked
          doors[currentDoor] = new Door(i*gridWidth+j, true, levelLoc); //sets door to locked
          currentDoor++;
        }
        else if (c==unlockedDoors)//unlocked doors - sets up an unlocked door 
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, false); //sets the grid to unblocked
          doors[currentDoor] = new Door(i*gridWidth+j, false, levelLoc); //Sets the door to unlocked
          currentDoor++;
        }
        else if (c==stairsUpUp)//stairs going up and coming out up - these are all chosen because the player has to be moved when the use stairs, otherwise they would just be on the same location and be sent back up or down again.
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, false);
          stairs[currentStair] = new Stair(i*gridWidth+j, levelLoc, levelLoc+1, 1);
          currentStair++; 
        }
        else if (c==stairsUpDown)//stairs going up and coming out down
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, false);
          stairs[currentStair] = new Stair(i*gridWidth+j, levelLoc, levelLoc+1, 2);
          currentStair++; 
        }
        else if (c==stairsUpLeft)//stairs going up and coming out to the left
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, false);
          stairs[currentStair] = new Stair(i*gridWidth+j, levelLoc, levelLoc+1, 4);
          currentStair++;  
        }
        else if (c==stairsUpRight)//stairs going up and coming out to the right
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, false);
          stairs[currentStair] = new Stair(i*gridWidth+j, levelLoc, levelLoc+1, 3);
          currentStair++; 
        }
        else if (c==stairsDownUp)//stairs going down and coming out up
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, false);
          stairs[currentStair] = new Stair(i*gridWidth+j, levelLoc, levelLoc-1, 1);
          currentStair++;  
        }
        else if (c==stairsDownDown)//stairs going down and coming out down
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, false);
          stairs[currentStair] = new Stair(i*gridWidth+j, levelLoc, levelLoc-1, 2);
          currentStair++; 
        }
        else if (c==stairsDownLeft)//stairs going down and coming out to the left
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, false);
          stairs[currentStair] = new Stair(i*gridWidth+j, levelLoc, levelLoc-1, 4);
          currentStair++; 
        }
        else if (c==stairsDownRight)//stairs going down and coming out to the right
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, false);
          stairs[currentStair] = new Stair(i*gridWidth+j, levelLoc, levelLoc-1, 3);
          currentStair++; 
        }
        else //backup for anywhere the colouring went wrong
        {
          grids[i*gridWidth+j] = new Grid(j*gridSize+displacementX, i*gridSize+displacementY, true);
        }
      }
    }
    
  }
    
}

class Lever //In a larger game there would be many more instances of this class. In this case there are just two, hiding secret locations 
{
  int gridLoc, roomLoc, levelLoc; //Lever location
  PImage img; //Image placed over the hidden space.
  boolean pulled; //Once pulled they cannot be unpulled - tracks whether they need to draw or not
  int[] unlock; //Unblocks the grid at the hidden area (array because it can be a wide area)
  
  Lever(int x, int y, int z, String n, int[] u)
  {
    gridLoc = x;
    roomLoc = y;
    levelLoc = z;
    img = loadImage(n+".gif");
    unlock = u;
    pulled = false;
  }
  
  public void draw()
  {
    if (!pulled&&player.levelLoc==levelLoc&&player.roomLoc==roomLoc)
    {
      image(img,levels[levelLoc].grids[unlock[0]].posX,levels[levelLoc].grids[unlock[0]].posY);
    }
  }
  
  public void pull() //called by player.interact()
  {
    if (!pulled)
    {
      pulled = true; //tells the program not to draw this lever
      textDisplay.output.add("You pulled a lever.");
      for (int i=0;i<unlock.length;i++)
      {
        levels[levelLoc].grids[unlock[i]].blocked = false; //unblocks the grids that were hidden
      }
      textDisplay.output.add(" ");
    }
  } 
}

class Monster extends NPC 
{
  boolean missionGiven; //Checks if the monster has requested something of the player
  Monster(int x, int y, int z, String n, String a)
  {
    gridLoc = x; //Starting coordinate for the monster
    roomLoc = y; //Room occupied by the character(cannot leave)
    levelLoc = z;
    
    name = n;
    img = loadImage(name+".gif");
    token = a; //What the monster accepts to complete their mission
    missionGiven = false;
    calmed = false; //Starts false, thise are the creatures that must be calmed for Feddy to consider the game complete
    speech = loadStrings(name+".txt"); //Monster dialogue is kept at 10 lines
    
    direction = 1;
    yMove = levels[levelLoc].gridWidth; //Movement up or down 1 grid width
    xMove = 1;
    counter=0; 
    counterLimit = 3;//changes movement after 3 steps
  }
  
  public void speak()
  {
    textDisplay.output.add(name+": ");
    if (!missionStart) //Two generic lines to tell the player go talk to Freddy
    {
      if (millis()%2==1) {textDisplay.output.add(speech[0]);}//One of two lines of text that direct the player to the office
      else {textDisplay.output.add(speech[1]);}
    }
    else
    {
      if (!missionGiven)
      {
        textDisplay.output.add(speech[2]); //Three lines to request their item - some vague some obvious 
        textDisplay.output.add(speech[3]);
        textDisplay.output.add(speech[4]);
        textDisplay.output.add(" ");
        missionGiven = true; 
      }
      else if(missionGiven&&!calmed) //If mission is given and not complete
      {
        textDisplay.output.add(speech[5]); //Asks why the player hasn't completed the mission yet
        textDisplay.output.add(speech[6]);
        textDisplay.output.add(" ");
        boolean found = false;
        int counter = player.inventory.size()-1;
        while(counter>=0&&!found) //Checks if the player has completed mission - starts at the end because items are removed from the inventory during the loop
        {
          if (player.inventory.get(counter).equals(token)) //Checks if the item is in the players inventory
          {
            player.inventory.remove(counter);
            textDisplay.output.add(token+" has been removed from your inventory."); //Removes the item from the player's inventory - is now 'held' by the monster
            textDisplay.output.add(" ");
            textDisplay.output.add(speech[7]);
            textDisplay.output.add(speech[8]);
            found = true;
            calmed=true;
          }
          else {counter--;}
        }
      }
      else if (calmed)
      {
        if (millis()%2==1) //Two random lines to inform the player that the mission is over
        {
          textDisplay.output.add(speech[9]);
        }
        else
        {
          textDisplay.output.add(speech[10]);
        }
      }
    }
    textDisplay.output.add(" ");
  }
  
}

class NPC
{
  int gridLoc, roomLoc, levelLoc; //Location of the NPC
  PImage img; //the NPC image - considered an array for directional sprites but ran short on time
  String name; //Character name, necessary for speech, loading img and speech files and general reference
  String[] speech; //Lines of speech loaded from a text file in the data folder
  
  String token; //the item the NPC either requires or gives
  boolean calmed; //Used to determine the progress of the game. Game win if you calm all the spirits
    
  int direction; //Used to determine the direction the character moves in
  int yMove,xMove; //where they move to each round (generally the next grid square up, down, left or right).
  
  int counter; //Serves dual task either tracking movement or speech depending on the NPC 
  int counterLimit; //Changes the movements of the NPCs, makes sure they don't stick to the walls
    
  public void draw()
  {
    if (player.levelLoc==levelLoc&&player.roomLoc==roomLoc) //Draws if the player is in the same room and on the same level
    {
      image(img,levels[levelLoc].grids[gridLoc].posX,levels[levelLoc].grids[gridLoc].posY,gridSize*1.2f,gridSize*1.2f);
    }
  }
  
  public void move()
  {
    counter++;
    if(player.roomLoc!=roomLoc) //Characters only move when the player is out of the room - designed partially for simplicity
    {
      if (direction==0)
      {
        int newLoc = gridLoc-yMove;
        if (gridLoc<0) {gridLoc = 0;}
        if (levels[levelLoc].grids[newLoc].blocked||levels[levelLoc].grids[newLoc].room!=roomLoc||(counter%counterLimit==0)) //Checks if the npc hits an edge or has moved too long in one direction
        {
          direction=PApplet.parseInt(random(4)); //changes the direction randomly if the   can't go further
        }
        else
        {
          gridLoc = newLoc; //moves if not blocked
        }
      }
      else if (direction==1)
      {
        int newLoc = gridLoc+xMove;
        if (levels[levelLoc].grids[newLoc].blocked||levels[levelLoc].grids[newLoc].room!=roomLoc||(counter%counterLimit==0))
        {
          direction=PApplet.parseInt(random(4));
        }
        else
        {
          gridLoc = newLoc;
        }
      }
      else if (direction==2)
      {
        int newLoc = gridLoc+yMove;
        if (levels[levelLoc].grids[newLoc].blocked||levels[levelLoc].grids[newLoc].room!=roomLoc||(counter%counterLimit==0))
        {
          direction=PApplet.parseInt(random(4));
        }
        else
        {
          gridLoc = newLoc;
        }
      }
      else if (direction==3)
      {
        int newLoc = gridLoc-xMove;
        if (levels[levelLoc].grids[newLoc].blocked||levels[levelLoc].grids[newLoc].room!=roomLoc||(counter%counterLimit==0))
        {
          direction=PApplet.parseInt(random(4));
        }
        else
        {
          gridLoc = newLoc;
        }
      }
    }
  }
  
  public void speak()
  {}
}





    


class Player
{
  ArrayList<String> inventory; //Only the player has an Inventory - Only necessary to have a string list as they are only removed or their name is checked, they don't have to be drawn again
  int gridLoc, levelLoc, roomLoc; //Player's  location 
  float posX, posY; //Fixed - grid etc moves around the player
  PImage[] img; //Character sprite as an array - shows the image for the direction they are facing
  int direction, movement; 

  Player()
  {
    levelLoc = 1; //Starting location is on the first floor in the first room
    roomLoc = 1;
    img = new PImage[4];
    for (int i=0;i<4;i++)
    {
      img[i] = loadImage("player"+i+".gif");
    }
    gridLoc=324;
    posX = levels[levelLoc].grids[gridLoc].posX; //Used to make sure the the coordinates are correct to the starting location
    posY = levels[levelLoc].grids[gridLoc].posY;
    inventory = new ArrayList<String>();
    direction = 1; //Used to choose what the player interacts with when spacebar is pressed
    movement = gridSize; //Movement and checks are at their smoothest when the movement is the same as the gridSize
  }
  
  public void draw()
  {
    image(img[direction],posX,posY,gridSize*1.2f,gridSize*1.2f); //Draws player, slightly larger due to a misjudgement when drawing the sprites. 
  }
  
  public void climb() //Checks if the player is on any of the stairs and moves them up or down if they are (was easiest to give it its own function
  {
    for (int i=0; i<levels[levelLoc].stairs.length;i++)
    {
      if (levels[levelLoc].stairs[i].gridLoc == gridLoc)
      {
        levels[levelLoc].stairs[i].climb();
      }
    }
  }
  
  public void interact() //Called when spacebar pressed
  {
    int targetLoc = 0; //The grid location the player is targeting with their interaction
    
    if (direction == 0) {targetLoc = gridLoc-levels[levelLoc].gridWidth;} //if looking up the grid location is 40-80 grids back
    else if (direction == 1) {targetLoc = gridLoc+1;} //if looking right it's the next grid
    else if (direction == 2) {targetLoc = gridLoc+levels[levelLoc].gridWidth;} //if looking down the grid location is 40-80 grids ahead
    else if (direction == 3) {targetLoc = gridLoc-1;} //if looking left it's the previous grid
    
    for (int i=0;i<characters.size();i++) //Cycles through the characters to see if they are in front of you.
    {
      if(characters.get(i).levelLoc==levelLoc) //Checks if the character is on the same level as you (no point checking their grid if they aren't) 
      {
        if(characters.get(i).gridLoc==gridLoc||characters.get(i).gridLoc==targetLoc) //Checks both the player's location and the target location for simplicity when moving around
        {
          characters.get(i).speak(); //Call the characters speak function to start dialogue
          return; //leaves the function if the the player has interacted
        }
      }
    }
    for (int i=items.size()-1;i>=0;i--)
    {
      if (items.get(i).levelLoc==levelLoc)
      {
        if(items.get(i).gridLoc==gridLoc||items.get(i).gridLoc==targetLoc) 
        {
          items.get(i).pickUp(); //adds the items name to the player inventory
          items.remove(i); //Items that have been picked up do not need to exist as a separate object anymore so they are removed
          return; //leaves the function once the player has interacted
        }
      }
    }
    for (int i=0;i<levels[levelLoc].doors.length;i++)
    {
      if (levels[levelLoc].doors[i].gridLoc==gridLoc||levels[levelLoc].doors[i].gridLoc==targetLoc)
      {
        levels[levelLoc].doors[i].unlock(); //Unlocks the door if it is locked and the player has the key
        return;//leaves the function once the player has interacted
      }
    }
    for (int i=0;i<levers.length;i++)
    {
      if (levers[i].gridLoc==gridLoc||levers[i].gridLoc==targetLoc)
      {
        levers[i].pull(); //Pulls the lever clearing the target area
        return;//leaves the function once the player has interacted
      }
    }
    textDisplay.output.add("There is nothing here to interact with."); //Should only ever get here if nothing is done above (due to the return functions
    textDisplay.output.add(" ");
  }
  
  public void move(int x, int y, int d) //called when the directional keys are pressed - x and y are negative and positive so that only one function is necessary for directional checks
  {
    int newLoc = levels[levelLoc].whereAmI(posX+(x*movement),posY+(y*movement)); //Gets the grid coordinate after the move is made
    direction = d; //sets the new direction
    if (!(levels[levelLoc].grids[newLoc].blocked)) //Checks to see if the player can move through the new location, proceeds if they can
    {
      gridLoc = newLoc;
      roomLoc = levels[levelLoc].grids[gridLoc].room;
      for (int a=0;a<levels.length;a++) //Cycles through all the levels ensuring the grids all move together (simplifying stairs etc)
      {
        for (int i=0; i<levels[a].grids.length;i++) //moves all grid coordinates around the player (player character technically never moves).
        {
          levels[a].grids[i].posX-=x*movement;
          levels[a].grids[i].posY-=y*movement;
        }
      }
    }
  }
}

public void keyPressed()
{
  if (key==' ')
  {
    player.interact(); //Calls the interact function when spacebar is tapped
  }
  if (key==CODED)
  {
    if (keyCode==UP)
    {
      player.move(0,-1, 0); //calls the players move function - formerly this code was entirely processed from here, but I simplified it significantly and moved it to it's own process.
    }
    if (keyCode==DOWN)
    {
      player.move(0,1, 2);
    }
    if (keyCode==RIGHT)
    {
      player.move(1,0, 1);
    }
    if (keyCode==LEFT)
    {
      player.move(-1,0, 3);
    }
  }
}

class Room //Room class mostly used to obscure the rooms that the player is in.
{
  int [] gridLocs; //The locations on the grid that the room occupies - used to make it easier to reference them quickly with a for loop
  int levelLoc;
  int roomNo;
  
  Room (int l, int r)
  {
    levelLoc = l;
    roomNo = r;
    int temp=0;
    for (int i=0;i<levels[levelLoc].grids.length;i++)
    {
      if (levels[levelLoc].grids[i].room==roomNo) //Gets the size of the gridLoc array
      {
        temp++;
      }
    }
    gridLocs = new int[temp];
    temp=0;
    for (int i=0;i<levels[levelLoc].grids.length;i++)
    {
      if (levels[levelLoc].grids[i].room==roomNo) //Checks what grid coordinates are in the room
      {
        gridLocs[temp] = i; //Assigns grid coordinates to the gridLoc
        temp++;
      }
    }
  }
  
  public void draw()
  {
    if (player.roomLoc!=roomNo) //If on the correct level
    {
      for(int i=0;i<gridLocs.length;i++)
      {
        noStroke();
        rect(levels[levelLoc].grids[gridLocs[i]].posX,levels[levelLoc].grids[gridLocs[i]].posY,gridSize,gridSize); //fills every grid coordinate no in the same room as the player with black
      }
    }
  }
  
}
    

class Sadoka extends NPC //special version of the ghost class - necessary because she moves room
{
  boolean moved1, moved2; //Necessary for the unique circumstances of the character, in a larger system with more instance of this type the setup would be tightened.
  
  Sadoka (int x, int y, int z, String n, String t)
  {
    gridLoc = x; //Starting coordinate for the monster
    roomLoc = y; //Room occupied by the character(cannot leave)
    levelLoc = z;
    
    name = n;
    token = t;
    img = loadImage(name+".gif");
    calmed = true; //Starts true as doesn't need calming
    speech = loadStrings(name+".txt");
    
    moved1 = false; //Used to make sure the move action isn't constantly sending the sprite all over the place
    moved2=false;
    counter=2;
  }
  
  public void move() //Overrides the player's room and only happens once
  {
    if (moved1&&!moved2)
    {
      for (int i=0;i<characters.size();i++)
      {
        if (characters.get(i).name.equals("Kayako Saeki")&&characters.get(i).calmed) //Once particular character has been calmed, then this character moves to her location
        {
          moved2 = true; //Stops the program from checking again, saves time
          gridLoc = 1711;
          roomLoc=7;
        }
      }
    }
  }
  
  public void speak() //The same as the usual ghost dialogue but adds some actions when the character gives away their item (they disapppear)
  {
    textDisplay.output.add(name+": ");
    if (!missionStart)
    {
      if (millis()%2==1) {textDisplay.output.add(speech[0]);}//One of two lines of text that direct the player to the office
      else {textDisplay.output.add(speech[1]);}
    }
    else if (counter<speech.length-3)
    {
      textDisplay.output.add(speech[counter]);
      textDisplay.output.add(speech[counter+1]);
      counter+=2;
    }
    else if (counter<speech.length-1)
    {
      textDisplay.output.add(speech[speech.length-3]);
      textDisplay.output.add(speech[speech.length-2]);
      textDisplay.output.add(" ");
      counter+=2;
      player.inventory.add(token);
      moved1 = true; //First move done
      gridLoc = 0; //Changes location so that the character can no longer be seen
      roomLoc = 0;
      textDisplay.output.add("You received the "+token+" from "+name+".");      
    }
    else
    {
      textDisplay.output.add(speech[speech.length-1]);
    }
    textDisplay.output.add(" ");
  }
}

//Most variable setups go here to simplify the other pages


public void mapSetup() //Sets up the Level array 
{
  levels = new Level[5];
  levels[0] = new Level(3780, 60, 63, 0, 9+1, 11, 8, 23, 3); //Grid numbers, grid length, grid height, Level Number, Number of Rooms, Number of doors, number of stairs, displacement (to get all grids in equal position)
  levels[1] = new Level(8000, 80, 100, 1, 14+1, 44, 15, 3, 3); //the +1 represents the 0th room, the outside of each level
  levels[2] = new Level(2400, 40, 60, 2, 13+1, 14, 7, 23, 23);
  levels[3] = new Level(2400, 40, 60, 3, 8+1, 9, 6, 23, 23);
  levels[4] = new Level(2400, 40, 60, 4, 2+1, 1, 5, 23, 23); //These may seem like complex function calls but the amount needed previously was far worse

  for (int a=0;a<levels.length;a++)
  {
    for (int i=0;i<levels[a].rooms.length;i++)
    {
      levels[a].rooms[i] = new Room(a,i); //Sets up the room arrays for each level
    }
  }
  keySetup(); //Sets up the keys for each locked door ( below)
}


public void setupCharacters()
{
  characters = new ArrayList<NPC>(); //Total characters: 10 Blink, 36 Graves, 12 Monsters, 13 Ghosts, 6 Creepy Girls, 1 Freddy
  for (int i=0;i<10;i++)
  {
    characters.add(new Blink(115+i)); //Setting up the angel statues, they are merely decoration and aren't relevant to the game - they all start in a line but move from there
  }
  PImage temp = loadImage("graves.gif"); //Setting up graves, quickest way was using an image to get their coordinates and then checking them the same as happens in the Level class
  image(temp,levels[1].displacementX,levels[1].displacementY); 
  for (int i=0;i<levels[1].grids.length;i++)
  {
    int c = get(PApplet.parseInt(levels[1].grids[i].posX+1),PApplet.parseInt(levels[1].grids[i].posY+1));
    int check = color(255,0,0);
    if (c==check) 
    {
      characters.add(new Grave(i)); //Setting up the gravestones, despite not really being characters they interact in the same way
    }
  }
  //Adding Monsters that we are trying to 'calm' (doing fetch quests for them)
  characters.add(new Monster(940, 2, 0, "Mummy", "Tape")); //gridLoc, roomLoc, levelLoc, name, and token
  characters.add(new Monster(1840, 7, 0, "Frankenstein's Monster", "Paradise Lost"));
  characters.add(new Monster(2607, 9, 0, "Frederick Loren", "Skeleton Puppet"));
  characters.add(new Monster(4030, 4, 1, "Hannibal Lector", "Human Flesh"));
  characters.add(new Monster(4369, 11, 1, "Dracula", "Garlic"));
  characters.add(new Monster(3162, 5, 1, "Jack Torrance", "Whiskey"));
  characters.add(new Monster(126, 1, 2, "Phantom", "Record"));
  characters.add(new Monster(545, 4, 2, "Norman Bates", "Mother's Gown"));
  characters.add(new Monster(1723, 11, 2, "Regan MacNeil", "Pea Soup"));
  characters.add(new Monster(1323, 6, 3, "Carrie White", "Matilda"));
  characters.add(new Monster(1709, 7, 3, "Kayako Saeki", "Corrupted Video Tape"));
  characters.add(new Monster(285, 1, 4, "Pinhead", "Puzzle Box"));
  
  //Adding Ghosts - mostly provide keys for the locked doors
  characters.add(new Ghost(1962, 8, 3, "Dr Jekyll", "Lab Key")); //Balcony on the third floor (locked)
  characters.add(new Ghost(3906, 1, 1, "Seymour Krelborn", "Glasshouse Key")); //Garden somewhere
  characters.add(new Ghost(4589, 10, 1, "Delbert Grady", "Whiskey")); //In the ballroom
  characters.add(new Ghost(1712, 2, 4, "Kirsty Cotton", "Poolroom Key")); //In the attic
  characters.add(new Ghost(2174, 5, 0, "Santa Claus", "Chimney Key")); //Drunk in cellar
  characters.add(new Ghost(6070, 12, 1, "Security Guard", "Security Room Key")); //In the Garage
  characters.add(new Ghost(5630, 10, 1, "Christine Daae", "Mirror Key")); //Ballroom
  characters.add(new Ghost(1495, 9, 2, "Father Damien Karras", "Bedroom Key")); //In guest room (simple but it makes sense character wise)
  characters.add(new Ghost(738, 3, 2, "Nancy Thompson", "Balcony Key")); //Second floor spare room
  characters.add(new Ghost(580, 3, 2, "Lucy Westenra", "Tower Key")); //Second floor spare room
  
  //Ghost: Sadako Yamamura - has Corrupted Ring Tape (not a key, but it'll work)
  characters.add(new Sadoka(606, 2, 3, "Sadako Yamamura", "Corrupted Video Tape"));
  
  //Ghost: Audrey II - has human flesh (not a key, technically an item)
  characters.add(new Ghost(1906, 3, 1, "Audrey II", "Garlic"));
  
  //Sewer Entrance - Just here as a gag
  characters.add(new Ghost(39, 1, 0, "Sewer Entrance", "Sewer Slime"));
  
  //adding the creepy girls (class mostly just for fun)
  characters.add(new CreepyGirl(590, 4, 3, "Alma")); //Gridloc, roomLoc, LevelLoc, nameLoc
  characters.add(new CreepyGirl(822, 3, 3, "Grady Twins"));
  characters.add(new CreepyGirl(823, 3, 3, "Grady Twins"));
  characters.add(new CreepyGirl(622, 3, 3, "Skipping Girls"));
  characters.add(new CreepyGirl(623, 3, 3, "Skipping Girls"));
  characters.add(new CreepyGirl(624, 3, 3, "Skipping Girls"));
  
  characters.add(new Freddy()); // Big boss, all variables set up within Freddy class
}


public void itemSetup()
{
  items = new ArrayList<Item>();
  //gridLoc, roomLoc, levelLoc, Name
  items.add(new Item(7433, 13, 1, "Tape"));//For the Mummy - in the Garden Shed
  items.add(new Item(2694, 5, 1, "Paradise Lost")); //For Frankenstein's Monster - in the Library
  items.add(new Item(1099, 2, 4, "Skeleton Puppet")); //For Frederick Loren - in the Attic
  items.add(new Item(2200, 7, 0, "Human Flesh")); //For Hannibal - in the secret lab
  items.add(new Item(1657, 7, 3, "Record")); //For the Phantom - in the Playroom
  items.add(new Item(1368, 8, 2, "Mother's Gown")); //For Norman Bates
  items.add(new Item(4343, 4, 1, "Pea Soup")); //For Regan Macneil - in the kitchen
  items.add(new Item(3874, 5, 1, "Matilda")); //For Carrie White - in the Library
  items.add(new Item(4086, 1, 1, "Puzzle Box")); //For Pinhead -in the pool
}

public void keySetup() //Unfortunately the easiest way to enter the key's for each door was to write them all out - would have needed more and more complex colour grids to do it any other way
{
  levels[0].doors[0].token = "Tomb Key";
  levels[0].doors[1].token = "Tomb Key";
  levels[0].doors[2].token = "Tomb Key";
  levels[0].doors[3].token = "Lab Key";
  levels[0].doors[4].token = "Lab Key";
  levels[0].doors[6].token = "Lab Key";
  levels[0].doors[7].token = "Lab Key";
  levels[0].doors[8].token = "Lab Key";
  levels[0].doors[9].token = "Lab Key";
  
  levels[1].doors[0].token = "Tomb Key";
  levels[1].doors[1].token = "Tomb Key";
  levels[1].doors[8].token = "Glasshouse Key";
  levels[1].doors[9].token = "Glasshouse Key";
  levels[1].doors[12].token = "Glasshouse Key";
  levels[1].doors[13].token = "Glasshouse Key";
  levels[1].doors[14].token = "Glasshouse Key";
  levels[1].doors[15].token = "Glasshouse Key";
  levels[1].doors[19].token = "Glasshouse Key";
  levels[1].doors[20].token = "Glasshouse Key";
  levels[1].doors[21].token = "Poolroom Key";
  levels[1].doors[25].token = "Chimney Key";
  levels[1].doors[26].token = "Chimney Key";
  levels[1].doors[43].token = "Security Room Key";
  
  levels[2].doors[0].token = "Mirror Key";
  levels[2].doors[5].token = "Lab Key";
  levels[2].doors[9].token = "Bedroom Key";
  levels[2].doors[10].token = "Balcony Key";
  levels[2].doors[11].token = "Balcony Key";
  
  levels[3].doors[0].token = "Tower Key";
  levels[3].doors[7].token = "Balcony Key";
  levels[3].doors[8].token = "Balcony Key";
  
  levels[4].doors[0].token = "Chimney Key";
}

public void leverSetup() //Awkward setup
{
  levers = new Lever[2];
  PImage temp = loadImage("lever.gif"); //pool coordinates
  image(temp,levels[1].displacementX,levels[1].displacementY);
  int count=0;
  int[] tempA1; //Temporary array to be setup by scanning a colour map (for the pool coordinates)
  int check = color(255,0,0);
  for (int i=0;i<levels[1].grids.length;i++) //scans colour grid for the pool coordinates
  {
    int c = get(PApplet.parseInt(levels[1].grids[i].posX),PApplet.parseInt(levels[1].grids[i].posY));
    if (c==check) 
    {
      count++;
    }
  }
  tempA1 = new int[count];
  count=0;
  for (int i=0;i<levels[1].grids.length;i++) //Setting up the gravestones, despite not really being characters they interact in the same way
  {
    int c = get(PApplet.parseInt(levels[1].grids[i].posX),PApplet.parseInt(levels[1].grids[i].posY));
    if (c==check) 
    {
      tempA1[count] = i;
      count++;
    }
  }
  
  levers[0] = new Lever(3043,                                                                                                                                                                                                                                                                                                                                                                                                                                                  1, 1, "poolLever", tempA1); //GridLoc, RoomLoc, levelNo, Name, array of affected grid locations
  int[] tempA2 = {1274}; //Only one location affected
  levers[1] = new Lever(1272, 10, 2, "bookCaseLever", tempA2);
}

class Stair
{
  int gridLoc; //location of stair
  int levelLoc;
  
  int targetLevel; //Where the player is being moved to
  int targetGrid;
  int direction;
  int distance;
  
  Stair (int g, int ln, int tl, int d)
  {
    gridLoc = g; //current location and level on the grid
    levelLoc = ln;
    
    targetLevel = tl; //Level and grid that the stairs will take you to
    targetGrid = 0;
    
    direction = d; //How the stairs will move the grid around you (straight up usually doesn't work, hence the direction you move and the distance you move (to get past any blocked squares))
    distance = 1;
  }
  
  public void climb()
  {
    player.levelLoc = targetLevel;
    
    if (direction==1) //up
    {
      player.move(0,-1*distance,0); //Uses the move function to send the player different directions after changing the level
    }
    else if (direction==2) //down
    {
      player.move(0,distance,1);
    }
    else if (direction==3) //right
    {
      player.move(distance,0,2);
    }
    else if (direction==4) //left
    {
      player.move(-1*distance,0,3);
    }
  }
}

class UI
{
  float posX, posY;
  float w,h;
  int spacing;
  
  public void draw() //Draws a black square representing the UI - fairly basic background for the text
  {
    stroke(100);
    strokeWeight(6);
    noFill();
    rect(0,0,800,700);
    strokeWeight(2);
    fill(0);
    rectMode(CORNER);
    rect(posX,posY,w,h);
  }
  
  public void printToScreen()
  {
  }
}

class OutputText extends UI
{
  ArrayList<String> output;
  
  OutputText()
  {
    posX = 0;
    posY = 700;
    w = width;
    h = 200;
    spacing = 15;
    output = new ArrayList<String>(); //Sets up the string
    output.add("Welcome to the Mystery of Wendsleydale Manor"); //Starting text to get the charager going
    output.add("Please use the arrow keys to move around and space to interact.");
    output.add(" ");
    output.add("You wake up in the dark, alone and confused");
    output.add("Some scrabbling shows you are in a coffin.");
    output.add("You force your way through rotting would and compacted earth to reach the surface");
    output.add("You are standing in the middle of a swamp on the grounds of a large manor house.");
    output.add("It looks like you can get across the debris to the Jetty.");
    output.add("Maybe someone at the house will know what is going on.");
    output.add(" ");
  }
  
  public void updateOutput()
  {
    if (output.size()>13) //Removes the first element if the output gets longer than the screen
    {
      output.remove(0);
    }
  }
  
  public void printToScreen() 
  {
    
    textSize(spacing);
    fill(255,0,0);
    text("Interactions: ", posX+spacing,posY+spacing); 
    fill(255);
    for (int i=output.size()-1;i>=0;i--)
    {
      text(output.get(i),posX+spacing,posY+(2*spacing)+(i*spacing)); //Writes the output arrayList to the screen
    }
  }
}

class InventoryText extends UI
{
  InventoryText()
  {
    posX = 800;
    posY = 0;
    w = 200;
    h = height;
    spacing = 15;
  }
  
  public void printToScreen()
  {
    fill(255,0,0);
    textSize(spacing);
    text("Inventory: ", posX+spacing,posY+spacing);
    fill(255);
    for (int i = player.inventory.size()-1;i>=0;i--)
    {
      text(player.inventory.get(i),posX+spacing,posY+(2*spacing)+(i*spacing)); //Writes the player's inventory to the screeen
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "theMysteryOfWensleydaleManor" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
